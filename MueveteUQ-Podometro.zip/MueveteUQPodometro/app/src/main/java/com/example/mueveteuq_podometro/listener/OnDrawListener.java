package com.example.mueveteuq_podometro.listener;

import com.google.android.gms.maps.model.LatLng;

public interface OnDrawListener {

    void onDraw(LatLng latLng);
}
