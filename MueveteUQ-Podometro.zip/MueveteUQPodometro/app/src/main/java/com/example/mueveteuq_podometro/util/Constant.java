package com.example.mueveteuq_podometro.util;

public class Constant {

    //Constante utillizada para crear una accion personalizada (Buscar: BroadCastReceiver para mas info)
    public static final String MYACTION = "com.example.mueveteuq_podometro.MYACTION";
    public static final String DBNAME = "podometrodb";
    public static final String SHARED = "preferencias";
    public static final String CURRENT_RACE = "current_race";
}
