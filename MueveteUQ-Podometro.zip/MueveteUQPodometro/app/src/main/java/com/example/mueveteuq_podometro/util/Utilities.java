package com.example.mueveteuq_podometro.util;

public class Utilities {


}
